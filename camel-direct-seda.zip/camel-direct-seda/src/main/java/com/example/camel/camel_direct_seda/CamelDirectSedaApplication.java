package com.example.camel.camel_direct_seda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelDirectSedaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelDirectSedaApplication.class, args);
	}

}
