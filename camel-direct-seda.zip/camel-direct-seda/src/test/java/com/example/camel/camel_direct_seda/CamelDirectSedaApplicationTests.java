package com.example.camel.camel_direct_seda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelDirectSedaApplicationTests {

	@Test
	void contextLoads() {
	}

}
